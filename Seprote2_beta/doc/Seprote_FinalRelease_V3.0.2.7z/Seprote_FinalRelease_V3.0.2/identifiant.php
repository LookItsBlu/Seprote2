<?php

	$user = "root";
	$pass = "";

?>
